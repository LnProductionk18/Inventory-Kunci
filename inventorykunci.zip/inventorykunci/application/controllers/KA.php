<?php  
	defined('BASEPATH') OR exit('NO direct script access allowed');
	class KA extends CI_Controller
	{
		function __construct()
		{
			parent::__construct();
			$this->load->model('m_login');
		}
		function index()
		{
			if ($this->session->userdata('level')=="1") 
			{
				$tmpl['nama_akun'] = $this->session->userdata('nama');
				$this->load->view('template/headerkunci',$tmpl);
				$tmpl['kunci']=$this->m_login->tampil_kunci();
				$this->load->view('homeka',$tmpl);
			}
			else
			{
				echo "<script>alert('Anda Tidak memiliki akses pada laman ini!');history.go(-1);</script>";
			}

		}

		// function crud data akun/akses
		function dataakun()
		{
			if ($this->session->userdata('level')=="1") 
			{
				$tmpl['nama_akun'] = $this->session->userdata('nama');
				$this->load->view('template/headerkunci',$tmpl);
				$tmpl['akun']=$this->m_login->tampil_akun();
				$this->load->view('akun', $tmpl);
			}
			else
			{
				echo "<script>alert('Anda Tidak memiliki akses pada laman ini!');history.go(-1);</script>";
			}

		}

		// function simpan_akun()
		// {
		// 	$nama 			=$this->input->post('nama');
		// 	$username 	 	=$this->input->post('username');
		// 	$password 		=md5($this->input->post('password'));
		// 	$level 			=$this->input->post('level');
		// 	$this->m_login->simpan_akun($nama,$username,$password,$level);
		// 	redirect('KA/dataakun');
		// }

		function edit_akun()
		{
			$idakses 		=$this->input->post('idakses');
			$nama 			=$this->input->post('nama');
			$username 	 	=$this->input->post('username');
			$password 		=md5($this->input->post('password'));
			// $level 			=$this->input->post('level');
			$this->m_login->edit_akun($idakses,$nama,$username,$password);
			redirect('KA/dataakun');
		}

		function hapus_akun()
		{
			$idakses=$this->input->post('idakses');
			$this->m_login->hapus_akun($idakses);
			redirect('KA/dataakun');
		}
		// end function crud data akun/akses

		function kuncip()
		{
			if ($this->session->userdata('level')=="1") 
			{
				$tmpl['nama_akun'] = $this->session->userdata('nama');
				$this->load->view('template/headerkunci',$tmpl);
				$tmpl['kunci']=$this->m_login->tampil_kunci();
				$this->load->view('kuncip',$tmpl);
			}
			else
			{
				echo "<script>alert('Anda Tidak memiliki akses pada laman ini!');history.go(-1);</script>";
			}

		}

		function simpan_kunci()
		{
			$kodekuncip 			=$this->input->post('kodekuncip');
			$namakunci 	 	=$this->input->post('namakunci');
			$this->m_login->simpan_kunci($kodekuncip,$namakunci);
			redirect('KA/kuncip');
		}

		function edit_kunci()
		{
			$idkuncip 			=$this->input->post('idkuncip');
			$namakunci 	 		=$this->input->post('namakunci');
			$this->m_login->edit_kunci($idkuncip,$namakunci);
			redirect('KA/kuncip');
		}

		function pinjam_kunci()
		{
			$idkuncip 	=$this->input->post('idkuncip');
			$namapeminjam 	 	=$this->input->post('namapeminjam');
			$waktupinjam 	 	=$this->input->post('waktupinjam');
			$statuspinjam 		= "dipinjam";
			$this->m_login->pinjam_kunci($idkuncip,$namapeminjam,$waktupinjam,$statuspinjam);
			redirect('KA/kuncip');
		}

		function kembali_kunci()
		{
			$idkuncip 			=$this->input->post('idkuncip');
			$kodekuncipr 	 	=$this->input->post('kodekuncip');

			$namakunci 	 		=$this->input->post('namakunci');
			$namakuncipr 	 		=$this->input->post('namakunci');

			$namapeminjam 	 	="";
			$namapeminjamr 	 	=$this->input->post('namapeminjam');

			$statuspinjam		="tersedia";
			$satuspinjamr		="Dikembalikan";


			$waktupinjam 	 	="";
			$waktupinjamr 	 	=$this->input->post('waktupinjam');

			$waktukembalir 	 	=$this->input->post('waktukembali');

			$this->m_login->kembali_kunci($idkuncip,$namapeminjam,$statuspinjam,$waktupinjam);
			$this->m_login->simpan_riwayatkunci($kodekuncipr,$namakuncipr,$namapeminjamr,$satuspinjamr,$waktupinjamr,$waktukembalir);

			redirect('KA/kuncip');
		}

		function hapus_kunci()
		{
			$idkuncip=$this->input->post('idkuncip');
			$this->m_login->hapus_kunci($idkuncip);
			redirect('KA/kuncip');
		}

		function riwayatkunci()
		{
			if ($this->session->userdata('level')=="1") 
			{
				$tmpl['nama_akun'] = $this->session->userdata('nama');
				$this->load->view('template/headerkunci',$tmpl);
				$tmpl['kunci']=$this->m_login->tampil_riwayatkunci();
				$this->load->view('riwayatpinjam',$tmpl);
			}
			else
			{
				echo "<script>alert('Anda Tidak memiliki akses pada laman ini!');history.go(-1);</script>";
			}

		}


		Public function logout()
	 	{
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('level');
			session_destroy();
			redirect('loby');
		}
	}
?>