<?php  
	defined('BASEPATH') OR exit('NO direct script access allowed');
	class Adm extends CI_Controller
	{
		function __construct()
		{
			parent::__construct();
			$this->load->model('m_login');
		}
		function index()
		{
			if ($this->session->userdata('level')=="2") 
			{
				$tmpl['nama_akun'] = $this->session->userdata('nama');
				$this->load->view('template/headerkunci',$tmpl);
				$this->load->view('homeadm');
			}
			else
			{
				echo "<script>alert('Anda Tidak memiliki akses pada laman ini!');history.go(-1);</script>";
			}
		}


		Public function logout()
	 	{
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('level');
			session_destroy();
			redirect('loby');
		}
	}