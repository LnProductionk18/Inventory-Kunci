<?php 
class m_login extends CI_Model
{	
	public function cekuser($data)
	{
		$cek = $this->db->get_where('akses',$data);
		return $cek;
	}
	// function data akun / akses
	public function tampil_akun()
	{
		$show = $this->db->query("SELECT * FROM akses ORDER BY nama ASC");
		return $show;
	}

	// function simpan_akun($nama,$username,$password,$level)
	// {
	// 	$save=$this->db->query("INSERT INTO akses (nama, username, password, level)
	// 	 VALUES ('$nama','$username', '$password', '$level')");
	// 	return $save;
	// }

	function edit_akun($idakses,$nama,$username,$password)
	{
		$hasil=$this->db->query("UPDATE akses SET nama='$nama', username='$username',password='$password' WHERE idakses='$idakses'");
		return $hsl;
	}

	function hapus_akun($idakses)
	{
		$hasil=$this->db->query("DELETE FROM akses WHERE idakses='$idakses'");
		return $hasil;
	}
	// end function data akun / akses


	//  function crud kunci dan insert into riwayat kunci
	public function tampil_kunci()
	{
		$show = $this->db->query("SELECT * FROM kuncip ORDER BY namakunci ASC");
		return $show;
	}

	function simpan_kunci($kodekuncip,$namakunci)
	{
		$save=$this->db->query("INSERT INTO kuncip (kodekuncip, namakunci)
		 VALUES ('$kodekuncip','$namakunci')");
		return $save;
	}

	function edit_kunci($idkuncip,$namakunci)
	{
		$hasil=$this->db->query("UPDATE kuncip SET namakunci='$namakunci' WHERE idkuncip='$idkuncip'");
		return $hsl;
	}

	function pinjam_kunci($idkuncip,$namapeminjam,$waktupinjam,$statuspinjam)
	{
		$hasil=$this->db->query("UPDATE kuncip SET namapeminjam='$namapeminjam', waktupinjam='$waktupinjam',statuspinjam='$statuspinjam' WHERE idkuncip='$idkuncip'");
		return $hsl;
	}

	function kembali_kunci($idkuncip,$namapeminjam,$statuspinjam,$waktupinjam)
	{
		$hasil=$this->db->query("UPDATE kuncip SET namapeminjam='$namapeminjam', statuspinjam='$statuspinjam',waktupinjam='$waktupinjam' WHERE idkuncip='$idkuncip'");
		return $hasil;
	}

	function hapus_kunci($idkuncip)
	{
		$hasil=$this->db->query("DELETE FROM kuncip WHERE idkuncip='$idkuncip'");
		return $hasil;
	}

	public function tampil_riwayatkunci()
	{
		$show = $this->db->query("SELECT * FROM riwayatkuncip ORDER BY namakuncipr ASC");
		return $show;
	}

	function simpan_riwayatkunci($kodekuncipr,$namakuncipr,$namapeminjamr,$satuspinjamr,$waktupinjamr,$waktukembalir)
	{
		$save=$this->db->query("INSERT INTO riwayatkuncip (kodekuncipr, namakuncipr, namapeminjamr, satuspinjamr ,waktupinjamr ,waktukembalir)
		 VALUES ('$kodekuncipr','$namakuncipr', '$namapeminjamr', '$satuspinjamr', '$waktupinjamr', '$waktukembalir')");
		return $save;
	}
	//  end function crud kunci dan insert into riwayat kunci
}
?>