<div class="container">
	<p>Admin</p>
	<a href="<?php echo base_url('Adm/logout'); ?>">Logout</a></li>

	<br><br><br> 	
	<footer style="color: white;">
	    <center><p>Copyright &copy; 2020 | <b>Megawati</b>. All rights reserved.</p></center>  
	</footer>
</div>