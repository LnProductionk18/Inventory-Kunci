<!DOCTYPE html>
<html>
<head>
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <?php  
    if ($this->session->userdata('level')=='1') 
    {
  ?>
      <title>Inventory Kunci [Ketua Admin] <?php echo $nama_akun; ?></title>
  <?php
    }
    elseif ($this->session->userdata('level')=='2')
    {
  ?>
     <title>Inventory Kunci [Admin] <?php echo $nama_akun; ?></title>
  <?php
    }
  ?>
  
  <link rel="icon" href="<?php echo base_url().'assets/pic/kunci.png';?>">

  <!---------------------------------------- BOOTSTRAP 4.3.1 CSS -------------------------------------->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/4.3.1/css/bootstrap.min.css'; ?>">

  <!---------------------------------------- DATATABLES CSS -------------------------------------->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'DataTables/datatables.min.css'?>"/>

  <!---------------------------------------- DATATABLES DARK THEME -------------------------------------->
  <link rel="stylesheet" href="<?php echo base_url().'DataTables/dark.scss'?>">

  <!---------------------------------------- BOOTSTRAP 4.3.1 JS -------------------------------------->
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/jquery-3.3.1.slim.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/popper.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/bootstrap.min.js'; ?>"></script>

  <!---------------------------------------- DATATABLES JS -------------------------------------->
  <script type="text/javascript" src="<?php echo base_url().'DataTables/datatables.min.js' ?>"></script>

  <script>
    $(document).ready(function() {
      $('#mydata').DataTable( {
        fixedHeader: true,
        dom: 'Bfrtip',
        lengthMenu: [
        [ 10, 25, 50, -1 ],
        [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        buttons: ['pageLength',
        {
          extend: 'print',
          orientation: 'landscape',
          exportOptions: {
            columns: ':visible',

          }
        },
        {
          extend: 'copyHtml5',
          orientation: 'landscape',
          exportOptions: {
            columns: [ 0, ':visible' ]
          }
        },
        {
          extend: 'excelHtml5',
          orientation: 'landscape',
          exportOptions: {
            columns: ':visible'
          }
        },
        {
          extend: 'pdfHtml5',
          orientation: 'landscape',
          exportOptions: {
            columns: ':visible'
          }
        },
        'colvis'
        ], select: true
      } );

    $('#mydatafo').DataTable();

      $('.form-checkbox').click(function(){
        if($(this).is(':checked')){
          $('.form-password').attr('type','text');
        }else{
          $('.form-password').attr('type','password');
        }
      });

    } );



      // Loading Page
      var myVar;

      function myFunction() {
        myVar = setTimeout(showPage, 500);
      }

      function showPage() {
        document.getElementById("loader").style.display = "none";
        document.getElementById("myDiv").style.display = "block";
      }
    </script>

    <script src="<?php echo base_url().'assets/js/jquery.mask.min.js';?>"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        // Format mata uang.
        $( '.uang' ).mask('000.000.000.000.000', {reverse: true});
        $( '.notelp' ).mask('0000-0000-0000-0000', {reverse: true});
      })
    </script>
<!--     <script type="text/javascript">
      setTimeout(function(){
       window.location.reload(1);
    }, 5000);
    </script>
     -->
    <style media="screen">
      html,body {
        height:100%;
      }

      input, textarea, select {
        margin-bottom: 10px;
      }

      thead {
        background-color: #052f3b;
      }

      #tambahdata {
        -moz-transition: all .3s;
        -o-transition: all .3s;
        -webkit-transition: all .3s;
        transition: all .3s;
      }
      #tambahdata:hover {
        background-image: linear-gradient(#151424, #1ad630);
        border-color: #1ad630;
      }

      #inputenable {
        color: white;
        /*border-color: #333333;*/
        border-style: none;
        background-color: #343A40;
      }

      #inputdisable {

        color: #919191;
        background-color: rgba(0,0,0,0);
        border-color: #333333;
      }

      /*#gambar {
        width: 0.1px;
        height: 0.1px;
        opacity: 0;
        overflow: hidden;
        position: absolute;
        z-index: -1;
        max-width: 80%;
      }*/

      #gambar:hover {
        background-color: #00470a;
      }

      label {
        color: white;
        text-align: right;
        font-size: 14px;
      }

      hr {
        background-color: gray;
      }

      h4 {
        color: white;
      }

      .btn {
        -webkit-transition-duration: 0.4s;
      }
      .btn:active {
        transform: translateY(3px);
      }

      .tabledark table {
        border: 1px solid black;
        color: white;
        text-align: center;
        font-size: 12px;
      }

      .tabledark th {
        border: 1px solid black;
        color: white;
        text-align: center;
        font-size: 12px;
        vertical-align: middle;
      }

      .tabledark td {
        border: 1px solid black;
        color: white;
        text-align: center;
        font-size: 12px;
        vertical-align: middle;
      }

      .bgnav{
        background-image: url('<?php echo base_url().'assets/pic/bghome.jpg';?>');
        background-size:cover; 
        background-attachment: fixed;
      }
      .navbar {
        background-color: transparent;
      }

      #loader {
        position: absolute;
        left: 50%;
        top: 50%;
        z-index: 1;
        width: 150px;
        height: 150px;
        margin: -75px 0 0 -75px;
        border: 16px solid #f3f3f3;
        border-radius: 50%;
        border-top: 16px solid #3498db;
        width: 120px;
        height: 120px;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
      }

      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      /* Add animation to "page content" */
      .animate-bottom {
        position: relative;
        -webkit-animation-name: animatebottom;
        -webkit-animation-duration: 1s;
        animation-name: animatebottom;
        animation-duration: 1s
      }

      @-webkit-keyframes animatebottom {
        from { bottom:-100px; opacity:0 }
        to { bottom:0px; opacity:1 }
      }

      @keyframes animatebottom {
        from{ bottom:-100px; opacity:0 }
        to{ bottom:0; opacity:1 }
      }

      #myDiv {
        display: none;
      }


    </style>

  </head>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
       <?php  
          if ($this->session->userdata('level')=='1') 
          {
        ?>
            <a class="navbar-brand" href="<?php echo base_url('KA'); ?>">Inventory Kunci</a>
        <?php  
          }
           elseif ($this->session->userdata('level')=='2')
          {
        ?>
           <a class="navbar-brand" href="<?php echo base_url('Adm'); ?>">Inventory Kunci</a>
        <?php  
          }
        ?>


      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
             <?php  
                if ($this->session->userdata('level')=='1') 
                {
              ?>
               <a class="nav-link" href="<?php echo base_url('KA'); ?>">Home <span class="sr-only">(current)</span></a>
              <?php
                }
                elseif ($this->session->userdata('level')=='2')
                {
              ?>
                <a class="nav-link" href="<?php echo base_url('Adm'); ?>">Home <span class="sr-only">(current)</span></a>
              <?php
                }
              ?>
          </li>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Kelola Data
            </a>
            <div class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
            <?php  
               if($this->session->userdata('level')=='1')
               {
            ?>
              <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url('KA/kuncip'); ?>">Data Kunci</a>
              <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url('KA/riwayatkunci'); ?>">Riwayat Peminjaman Kunci</a>
              <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url('KA/dataakun'); ?>">Data Akun</a>
            <?php 
               }
               elseif ($this->session->userdata('level')=='2') 
               {
            ?>
              <a class="dropdown-item bg-dark" style="color: white;" href="#">Data Peminjaman Kunci</a>
              <a class="dropdown-item bg-dark" style="color: white;" href="#">Riwayat Peminjaman Kunci</a>
             <?php
               }
            ?>
              <!-- <div class="dropdown-divider"></div> -->
              <!-- <a class="dropdown-item" href="#">*******</a> -->
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="" tabindex="-1" aria-disabled="true"> Hallo <?php echo $this->session->userdata('nama');?>!</a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <a href="<?php echo base_url('KA/logout'); ?>" class="btn btn-outline-danger my-2 my-sm-0">Logout</a>
        </form>
      </div>
    </nav>

    <body 
    onload="myFunction();tampilkanwaktu();setInterval('tampilkanwaktu()', 1000);" 
    class="bgnav">
      <div id="loader"></div>
        <div style="display:none;" id="myDiv" class="animate-bottom"></div>



