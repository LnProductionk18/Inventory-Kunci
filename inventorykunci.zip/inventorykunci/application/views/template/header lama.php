<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <?php
  $dari = new DateTime($this->input->post('tgl_dari'));
  $dari1=$dari->format('d M Y');

  $sampai = new DateTime($this->input->post('tgl_sampai'));
  $sampai1=$sampai->format('d M Y');

  if ($this->input->post('jenis_bayar')=='') {
    $jenisbayar = 'Tunai & Transfer';
  }
  else
    $jenisbayar = $this->input->post('jenis_bayar');

  $page = $_SERVER['PHP_SELF'];
  if ($page=='/bkvnethome/index.php/pendapatan/terfilter') { ?>
    <title>
      <?php echo 'Total Penghasilan ('.$dari1.' - '.$sampai1.') ('.$jenisbayar.')'; ?>
    </title> <?php
  }
  elseif ($page=='/bkvnethome/index.php/riwayat_pembayaran/terfilter') { ?>
    <title>
      <?php echo 'Riwayat Pembayaran ('.$dari1.' - '.$sampai1.') ('.$jenisbayar.')'; ?>
    </title> <?php
  }
  else { ?>
  <title>
    BKV NET HOME | 
    <?php 
      echo $this->session->userdata('name').' | ';
      if ($this->session->userdata('level')=='1')
         echo "BOS";
      elseif ($this->session->userdata('level')=='2')
        echo "IT";
      elseif ($this->session->userdata('level')=='3')
        echo "ACCOUNTING";
      elseif ($this->session->userdata('level')=='4')
        echo "ADMIN";
    ?>
      
  </title> <?php
  }
  ?>
  <link rel="icon" href="<?php echo base_url().'assets/pic/logonet2.png';?>">

  <!---------------------------------------- BOOTSTRAP 4.3.1 CSS -------------------------------------->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/4.3.1/css/bootstrap.min.css'; ?>">

  <!---------------------------------------- DATATABLES CSS -------------------------------------->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'DataTables/datatables.min.css'?>"/>

  <!---------------------------------------- DATATABLES DARK THEME -------------------------------------->
  <link rel="stylesheet" href="<?php echo base_url().'DataTables/dark.scss'?>">

  <!---------------------------------------- BOOTSTRAP 4.3.1 JS -------------------------------------->
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/jquery-3.3.1.slim.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/popper.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/bootstrap.min.js'; ?>"></script>

  <!---------------------------------------- DATATABLES JS -------------------------------------->
  <script type="text/javascript" src="<?php echo base_url().'DataTables/datatables.min.js' ?>"></script>

  <script>
    $(document).ready(function() {
      $('#mydata').DataTable( {
        fixedHeader: true,
        dom: 'Bfrtip',
        lengthMenu: [
        [ 10, 25, 50, -1 ],
        [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        buttons: ['pageLength',
        {
          extend: 'print',
          orientation: 'landscape',
          exportOptions: {
            columns: ':visible',

          }
        },
        {
          extend: 'copyHtml5',
          orientation: 'landscape',
          exportOptions: {
            columns: [ 0, ':visible' ]
          }
        },
        {
          extend: 'excelHtml5',
          orientation: 'landscape',
          exportOptions: {
            columns: ':visible'
          }
        },
        {
          extend: 'pdfHtml5',
          orientation: 'landscape',
          exportOptions: {
            columns: ':visible'
          }
        },
        'colvis'
        ], select: true
      } );

    $('#mydatafo').DataTable();

      $('.form-checkbox').click(function(){
        if($(this).is(':checked')){
          $('.form-password').attr('type','text');
        }else{
          $('.form-password').attr('type','password');
        }
      });

    } );



      // Loading Page
      var myVar;

      function myFunction() {
        myVar = setTimeout(showPage, 500);
      }

      function showPage() {
        document.getElementById("loader").style.display = "none";
        document.getElementById("myDiv").style.display = "block";
      }
    </script>

    <script src="<?php echo base_url().'assets/js/jquery.mask.min.js';?>"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        // Format mata uang.
        $( '.uang' ).mask('000.000.000.000.000', {reverse: true});
        $( '.notelp' ).mask('0000-0000-0000-0000', {reverse: true});
      })
    </script>
    
    <style media="screen">
      html,body {
        height:100%;
      }

      input, textarea, select {
        margin-bottom: 10px;
      }

      thead {
        background-color: #052f3b;
      }

      #tambahdata {
        -moz-transition: all .3s;
        -o-transition: all .3s;
        -webkit-transition: all .3s;
        transition: all .3s;
      }
      #tambahdata:hover {
        background-image: linear-gradient(#5bc0de, #052F3B);
        border-color: #052F3B;
      }

      #inputenable {
        color: white;
        /*border-color: #333333;*/
        border-style: none;
        background-color: #343A40;
      }

      #inputdisable {
        color: #919191;
        background-color: rgba(0,0,0,0);
        border-color: #333333;
      }

      /*#gambar {
        width: 0.1px;
        height: 0.1px;
        opacity: 0;
        overflow: hidden;
        position: absolute;
        z-index: -1;
        max-width: 80%;
      }*/

      #gambar:hover {
        background-color: #00470a;
      }

      label {
        color: white;
        text-align: right;
        font-size: 14px;
      }

      hr {
        background-color: gray;
      }

      h1 {
        color: white;
      }

      .btn {
        -webkit-transition-duration: 0.4s;
      }
      .btn:active {
        transform: translateY(3px);
      }

      .tabledark table {
        border: 1px solid black;
        color: white;
        text-align: center;
        font-size: 12px;
      }

      .tabledark th {
        border: 1px solid black;
        color: white;
        text-align: center;
        font-size: 12px;
        vertical-align: middle;
      }

      .tabledark td {
        border: 1px solid black;
        color: white;
        text-align: center;
        font-size: 12px;
        vertical-align: middle;
      }

      .bgnav{
        background-image: url('<?php echo base_url().'assets/pic/header-bg.jpg';?>');
        background-size:cover; 
        background-attachment: fixed;
      }
      .navbar {
        background-color: transparent;
      }

      #loader {
        position: absolute;
        left: 50%;
        top: 50%;
        z-index: 1;
        width: 150px;
        height: 150px;
        margin: -75px 0 0 -75px;
        border: 16px solid #f3f3f3;
        border-radius: 50%;
        border-top: 16px solid #3498db;
        width: 120px;
        height: 120px;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
      }

      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      /* Add animation to "page content" */
      .animate-bottom {
        position: relative;
        -webkit-animation-name: animatebottom;
        -webkit-animation-duration: 1s;
        animation-name: animatebottom;
        animation-duration: 1s
      }

      @-webkit-keyframes animatebottom {
        from { bottom:-100px; opacity:0 }
        to { bottom:0px; opacity:1 }
      }

      @keyframes animatebottom {
        from{ bottom:-100px; opacity:0 }
        to{ bottom:0; opacity:1 }
      }

      #myDiv {
        display: none;
      }

      /*.js .inputfile {
        width: 0.1px;
        height: 0.1px;
        opacity: 0;
        overflow: hidden;
        position: absolute;
        z-index: -1;
      }

      .inputfile + label {
        max-width: 80%;
        font-size: 1.25rem;
        font-weight: 700;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
        display: inline-block;
        overflow: hidden;
        padding: 0.625rem 1.25rem;
      }

      .no-js .inputfile + label {
        display: none;
      }

      .inputfile:focus + label,
      .inputfile.has-focus + label {
        outline: 1px dotted #000;
        outline: -webkit-focus-ring-color auto 5px;
      }

      .inputfile + label svg {
        width: 1em;
        height: 1em;
        vertical-align: middle;
        fill: currentColor;
        margin-top: -0.25em;
        margin-right: 0.25em;
      }

      .inputfile-1 + label {
        color: #f1e5e6;
        background-color: #024200;
      }

      .inputfile-1:focus + label,
      .inputfile-1.has-focus + label,
      .inputfile-1 + label:hover {
        background-color: #012400;
        transition: .3s all ease-in;
      }*/

    </style>

  </head>

    <?php
    $x=0;
    $query=$this->m_pelanggan->show_h3();

    foreach($query->result_array() as $i):
      $x++;
      $pelanggan_idpel=$i['idpelanggan'];
      $pelanggan_idclihid=$i['idclihid'];
      $pelanggan_idpak=$i['idpaket'];
      $pelanggan_biaya=$i['biaya'];
      $pelanggan_tgl=$i['tgl_langgan'];
      $pelanggan_tempo=$i['tgl_tempo'];
      $pelanggan_bayar=$i['bayar'];
      $pelanggan_totbayar=$i['totbayar'];
      $pelanggan_awalsus=$i['awalsus'];

    endforeach;
    ?>

    <nav class="navbar navbar-expand-lg navbar-dark" style="margin-bottom: 20px;">
      <a class="navbar-brand" href="<?php echo base_url().'pelanggan';?>">
        <img src="<?php echo base_url("assets/pic/bkv.png"); ?>" height="30" class="d-inline-block align-top" alt="">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                Kelola Data
              </a>
              <div class="dropdown-menu bg-dark">
                <?php if($this->session->userdata('level')=='1' or $this->session->userdata('level')=='2' or $this->session->userdata('level')=='3') { ?>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("pelanggan"); ?>">Data Berlangganan</a>
                   <?php 
                } ?>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("client"); ?>">Data Client</a>
                <?php if($this->session->userdata('level')=='1' or $this->session->userdata('level')=='2') { ?>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("paket"); ?>">Data Paket</a>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("user"); ?>">Data User</a>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("lokasi"); ?>">Data Lokasi</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("verifikasi_pembayaran/pembayaran"); ?>">Verifikasi Pembayaran</a>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("verifikasi_pembayaran/pindah"); ?>">Verifikasi Pindah Lokasi</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("index.php/backup/db"); ?>">Backup Database</a> <?php 
                }
                if($this->session->userdata('level')=='1') { ?>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("index.php/backup/files"); ?>">Backup All</a> <?php } ?>
              </div>
            </li>
            <li class="nav-item">
              <?php
              if ($x==0) { ?>
                <a class="nav-link" href="<?php echo base_url("notifikasi"); ?>">
                  H-3 Pembayaran (<?php echo $x; ?>)
                </a>
                <?php
              }
              elseif ($x>0) { ?>
                <a class="nav-link" href="<?php echo base_url("notifikasi"); ?>">
                  H-3 Pembayaran <span style="color: red;">(<?php echo $x; ?>)</span>
                </a>
                <?php
              }
              ?>
            </li>

            <?php if($this->session->userdata('level')=='1' or $this->session->userdata('level')=='2') { ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url("riwayatpel"); ?>">Data Riwayat Pelanggan</a> 
              </li>
              <?php 
            } ?>

            <?php if($this->session->userdata('level')=='1' or $this->session->userdata('level')=='2') { ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                Laporan
              </a>
              <div class="dropdown-menu bg-dark">
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("Riwayat_Pindah"); ?>">Data Riwayat Pindah</a>    
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("riwayat_pembayaran"); ?>">Data Riwayat Pembayaran</a>
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url("pendapatan"); ?>">Data Pendapatan</a> 

              </div>
            </li>
            <?php } ?>

          </ul>

        </div>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
          <div class="dropdown-divider"></div>
          <ul class="navbar-nav">
            <li class="nav-item">
              <script type="text/javascript">        
              function tampilkanwaktu(){         //fungsi ini akan dipanggil di bodyOnLoad dieksekusi tiap 1000ms = 1detik    
              var waktu = new Date();            //membuat object date berdasarkan waktu saat 
              var sh = waktu.getHours() + "";    //memunculkan nilai jam, //tambahan script + "" supaya variable sh bertipe string sehingga bisa dihitung panjangnya : sh.length    //ambil nilai menit
              var sm = waktu.getMinutes() + "";  //memunculkan nilai detik    
              var ss = waktu.getSeconds() + "";  //memunculkan jam:menit:detik dengan menambahkan angka 0 jika angkanya cuma satu digit (0-9)
              document.getElementById("clock").innerHTML = (sh.length==1?"0"+sh:sh) + ":" + (sm.length==1?"0"+sm:sm) + ":" + (ss.length==1?"0"+ss:ss);
            }
            </script>
            <a class="nav-link">
            <span style="text-shadow: 0px 0px 5px green;" id="clock"></span>
            <span style="text-shadow: 0px 0px 5px green;"> | 
            <?php
            $hari = date('l');
            /*$new = date('l, F d, Y', strtotime($Today));*/
            if ($hari=="Sunday") {
             echo "Minggu";
            }elseif ($hari=="Monday") {
             echo "Senin";
            }elseif ($hari=="Tuesday") {
             echo "Selasa";
            }elseif ($hari=="Wednesday") {
             echo "Rabu";
            }elseif ($hari=="Thursday") {
             echo("Kamis");
            }elseif ($hari=="Friday") {
             echo "Jum'at";
            }elseif ($hari=="Saturday") {
             echo "Sabtu";
            }
            echo ", ";

            $tgl =date('d');
            echo $tgl;
            $bulan =date('F');
            if ($bulan=="January") {
             echo " Januari ";
            }elseif ($bulan=="February") {
             echo " Februari ";
            }elseif ($bulan=="March") {
             echo " Maret ";
            }elseif ($bulan=="April") {
             echo " April ";
            }elseif ($bulan=="May") {
             echo " Mei ";
            }elseif ($bulan=="June") {
             echo " Juni ";
            }elseif ($bulan=="July") {
             echo " Juli ";
            }elseif ($bulan=="August") {
             echo " Agustus ";
            }elseif ($bulan=="September") {
             echo " September ";
            }elseif ($bulan=="October") {
             echo " Oktober ";
            }elseif ($bulan=="November") {
             echo " November ";
            }elseif ($bulan=="December") {
             echo " Desember ";
            }
            $tahun=date('Y');
            echo $tahun;
          ?>
          </span>
          </a>
            </li>
          </ul>
          <ul class="navbar-nav">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                Selamat Datang <?php echo $this->session->userdata('name');?>!
              </a>
              <div class="dropdown-menu bg-dark">
                  <a class="dropdown-item bg-dark" style="color: white;" href="<?php echo base_url('pelanggan/logout'); ?>">Sign Out</a>
              </div>
            </li>
          </ul>

        </div>
      </nav>

      <body onload="myFunction();tampilkanwaktu();setInterval('tampilkanwaktu()', 1000);" class="bgnav">
        <div id="loader"></div>
        <div style="display:none;" id="myDiv" class="animate-bottom"></div>