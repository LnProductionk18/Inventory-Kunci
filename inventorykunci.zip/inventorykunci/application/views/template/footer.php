<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="icon" href="<?php echo base_url().'assets/pic/kunci.png';?>">

  <!---------------------------------------- BOOTSTRAP 4.3.1 CSS -------------------------------------->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/4.3.1/css/bootstrap.min.css'; ?>">

  <!---------------------------------------- DATATABLES CSS -------------------------------------->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'DataTables/datatables.min.css'?>"/>

  <!---------------------------------------- DATATABLES DARK THEME -------------------------------------->
  <link rel="stylesheet" href="<?php echo base_url().'DataTables/dark.scss'?>">

  <!---------------------------------------- BOOTSTRAP 4.3.1 JS -------------------------------------->
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/jquery-3.3.1.slim.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/popper.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/bootstrap.min.js'; ?>"></script>

  <!---------------------------------------- DATATABLES JS -------------------------------------->
  <script type="text/javascript" src="<?php echo base_url().'DataTables/datatables.min.js' ?>"></script>
</head>
<body>
  <br><br><br><br>
<footer style="color: white;">
    <center><p>Copyright &copy; 2020 | <b>Megawati</b>. All rights reserved.</p></center>  
</footer>
</body>
</html>