<!DOCTYPE html>
<html>
<head>
  
  <title>Login Inventory</title>
  <!--Made with love by Mutiullah Samim -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/4.3.1/css/bootstrap.min.css'; ?>">
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/jquery-3.3.1.slim.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/popper.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bootstrap/4.3.1/js/bootstrap.min.js'; ?>"></script>

  <link rel="icon" href="<?php echo base_url().'assets/pic/kunci.png';?>">

  <!--Custom styles-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/style_log.css"); ?>">

  <style type="text/css">
    #tambahdata {
      -moz-transition: all .3s;
      -o-transition: all .3s;
      -webkit-transition: all .3s;
      transition: all .3s;
    }
    #tambahdata:hover {
      background-image: linear-gradient(#5bc0de, #052F3B);
      border-color: #052F3B;
    }

    .btn {
      -webkit-transition-duration: 0.4s;
    }
    .btn:active {
      transform: translateY(3px);
    }

    #test {
      -webkit-animation: fadein 1s; /* Safari, Chrome and Opera > 12.1 */
      -moz-animation: fadein 1s; /* Firefox < 16 */
      -ms-animation: fadein 1s; /* Internet Explorer */
      -o-animation: fadein 1s; /* Opera < 12.1 */
      animation: fadein 1s;
    }

    @keyframes fadein {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

    /* Firefox < 16 */
    @-moz-keyframes fadein {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

    /* Safari, Chrome and Opera > 12.1 */
    @-webkit-keyframes fadein {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

    /* Internet Explorer */
    @-ms-keyframes fadein {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

    /* Opera < 12.1 */
    @-o-keyframes fadein {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

   /* #myVideo {
      position: fixed;
      width: 1500px;
      right: 0;
      bottom: 0;
      min-width: 100%; 
      min-height: 100%;
    }*/
    .bgmeja
    {
    	background-image: url(assets/pic/bgmeja.jpg);
    	background-size: cover;
    	/*position: fixed;*/
	   /* width: 1500px;
	    right: 0;
	    bottom: 0;
	    min-width: 100%; 
	    min-height: 100%;*/
    }
    .kuncilogin
    {
    	width: 40px;
    	height: 40px;
    }
  </style>

  <script type="text/javascript">
    $(document).ready(function(){

      $('[data-toggle="tooltip"]').tooltip();

      $('.form-checkbox').click(function(){
        if($(this).is(':checked')){
          $('.form-password').attr('type','text');
        }else{
          $('.form-password').attr('type','password');
        }
      });
    });
  </script>

</head>

<body class="bgmeja" onload="tampilkanwaktu();setInterval('tampilkanwaktu()', 1000);">
	<div class="container">
		<div class="d-flex justify-content-center h-100">
			<div class="card">
			 	<div class="card-header">
	              <h3><center> <img src="assets/pic/kunci.png" class="kuncilogin">Login</center></h3>
	              <div class="d-flex justify-content-end social_icon">
	                <span><i class="fab"></i></span>
	              </div>
	            </div>
	            <div class="card-body">
	            <?php echo form_open("Loby/cek_login", array('enctype'=>'multipart/form-data')); ?>
	             	<div class="input-group form-group">
                  		<div class="input-group-prepend">
                    		<span class="input-group-text"><img width="17px;" src="<?php echo base_url().'assets/pic/account.png';?>"><i class="fas fa-user"></i></span>
                  		</div>
                  		<input type="text" class="form-control" name="username" placeholder="username" autofocus>
                	</div>
                	<div class="input-group form-group">
                  		<div class="input-group-prepend">
                    		<span class="input-group-text"><img width="18px;" src="<?php echo base_url().'assets/pic/key.png';?>"><i class="fas fa-key"></i></span>
                  		</div>
                  		<input type="password" class="form-control form-password" name="password" placeholder="password">
                	</div>
                	<div class="row align-items-center remember">
                  		<div style="margin-left: 15px;" class="custom-control custom-checkbox mb-3">
                    		<input type="checkbox" class="custom-control-input form-checkbox" id="customCheck" name="example1">
                    		<label style="font-size: 14px;" class="custom-control-label" for="customCheck">Show Password</label>
                  		</div>
                	</div>
                	<div class="form-group"><br>
	                  <input id="tambahdata" 
	                  type="submit" value="Login" class="btn btn-lg btn-outline-info" style="">
	                </div>
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</body>
</html>