<?php
	function acak($panjang)
	{
		$karakter= 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
		$string = '';
		for ($i = 0; $i < $panjang; $i++) {
			$pos = rand(0, strlen($karakter)-1);
			$string .= $karakter{$pos};
		}
		return $string;
	}
	//cara memanggilnya
	$hasil_1= acak(5);
	$hasil_2= acak(10);
	?>
<div class="container">
	<center><h4 class="display-4">Data Kunci</h4><hr></center>
	 <button id="tambahdata" class="btn btn-lg btn-outline-success" data-toggle="modal" data-target="#modal_tambah">Tambah Kunci</button><br><br>
	  <table class="tabledark display compact" id="mydata" style="width: 99.9%;">
	  	<thead>
	  		<tr>
	  			<th><center>No</center></th>
	  			<th><center>Kode Kunci</center></th>
  			 	<th><center>Nama Kunci</center></th>
  			 	<th><center>Nama Peminjam</center></th>
  			 	<th><center>Status Kunci</center></th>
  			 	<th><center>Waktu Pinjam</center></th>
  			 	<!-- <th><center>Waktu Pengembalian</center></th> -->
  			 	<th><center>Kelola Data</center></th>
	  		</tr>
	  	</thead>
	  	<tbody>
	  		<?php  
        		$no = 0;
        		 foreach($kunci->result_array()as$terdaftar):
        		 	$no++;
        		 	$idkuncip=$terdaftar['idkuncip'];
        		 	$kodekuncip = $terdaftar['kodekuncip'];
        		 	$namakunci = $terdaftar['namakunci'];
        		 	$namapeminjam = $terdaftar['namapeminjam'];
        		 	$statuspinjam = $terdaftar['statuspinjam'];
        		 	$waktupinjam = $terdaftar['waktupinjam'];
        		 	$waktukembali = $terdaftar['waktukembali'];
        	?>
        	<tr>
        		<td align="center"><?php echo $no; ?></td>
                <td align="center"><?php echo $kodekuncip; ?></td>
                <td align="center"><?php echo $namakunci; ?></td>
                <td align="center"><?php echo $namapeminjam; ?></td>
                <?php  
                if ($statuspinjam == "tersedia")
                {
                	$ket = "Tersedia";
                ?>
                	 <td align="center" style="background-color: #006622;"><?php echo $ket; ?></td>
               	<?php
                }
                elseif ($statuspinjam == "dipinjam")
                {
                	$ket = "Dipinjam";
                ?>
                	<td align="center" style="background-color: #990000;"><?php echo $ket; ?></td>
                <?php
                }
                ?>
                <td align="center"><?php echo $waktupinjam; ?></td>
                <!-- <td align="center"><?php echo $waktukembali; ?></td> -->
                <td align="center">
                	<?php  
            		if ($statuspinjam == "tersedia") 
            		{
                	?>
                		<button class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal_pinjam<?php echo $idkuncip;?>">Pinjam</button>
                		<button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal_delete<?php echo $idkuncip;?>">Hapus</button>
                        <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#modal_edit<?php echo $idkuncip;?>">Edit</button>
					<?php                		
            		}
            		elseif ($statuspinjam == "dipinjam") 
            		{
                	?>
                		<button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#modal_pengembalian<?php echo $idkuncip;?>">Pengembalian</button>
                	<?php
            		}
                	?>
                   
                   
                </td>
        	</tr>
        	 <?php endforeach;?>
	  	</tbody>
	  </table>

	     <!-- Modal tambah kunci  -->
    <div class="modal fade" id="modal_tambah" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #26b7ba;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Daftar Data Kunci</h2>
                </div>
                <?php echo form_open("KA/simpan_kunci", array('enctype'=>'multipart/form-data')); ?>
                    <div class="modal-body">
                        <div class="form-group row">
                        	<label class="control-lable col-4"><!-- Kode Kunci --></label>
                            <div class="col-8">
                                <input id="inputenable" type="text" name="kodekuncip" class="form-control" type="text" value="<?php echo $hasil_1; ?>"  readonly hidden>
                            </div>

                            <label class="control-lable col-4">Nama Kunci</label>
                            <div class="col-8">
                                <input id="inputenable" type="text" name="namakunci" class="form-control" type="text" required autofocus>
                            </div>    
                           
                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-success" type="submit">Tambah</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
             	<?php echo form_close(); ?>
          </div>
      </div>
  	</div >
  		<!-- end modal tambah kunci -->

  		<!-- modal peminjaman kunci -->
	<?php 
        foreach($kunci->result_array() as $i):
        $idkuncip=$i['idkuncip'];
	 	$kodekuncip = $i['kodekuncip'];
	 	$namakunci = $i['namakunci'];
	 	$namapeminjam = $i['namapeminjam'];
	 	$statuspinjam = $i['statuspinjam'];
	 	$waktupinjam = $i['waktupinjam'];
	 	$waktukembali = $i['waktukembali'];
    ?>
    <div class="modal fade" id="modal_pinjam<?php echo $idkuncip;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">

                <div class="alert" style="background-color: #bd7400;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Form Peminjaman Kunci</h2>
                </div>

                <form class="form-horizontal" method="post" action="<?php echo base_url().'KA/pinjam_kunci/'.$idkuncip;?>">
                    <div class="modal-body">

                        <div class="form-group row">
                        	 <input name="idkuncip" value="<?php echo $idkuncip;?>" class="form-control" type="hidden" placeholder="ID pendaftaran..." readonly>
                            <label class="control-label col-4" >Nama Kunci</label>
                            <div class="col-8">
                                <input id="inputenable" value="<?php echo $namakunci;?>" class="form-control" type="text" readonly>
                            </div>
                        
                            <label class="control-label col-4" >Nama Peminjam</label>
                            <div class="col-8">
                                <input id="inputenable" name="namapeminjam" value="<?php echo $namapeminjam;?>" class="form-control" required>
                            </div>   

                            <label class="control-label col-4" >Waktu Peminjaman</label>
                            <div class="col-8">
                                <input id="inputenable" type="datetime-local" name="waktupinjam" value="<?php echo $waktupinjam;?>" class="form-control" required>
                            </div>     

                        </div>

                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-info" type="submit">Pinjam</button>
                            <button class="btn btn-secondary" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php endforeach;?>
<!-- end modal peminjaman kunci -->

	<!-- modal pengembalian kunci -->
	<?php 
        foreach($kunci->result_array() as $i):
        $idkuncip=$i['idkuncip'];
	 	$kodekuncip = $i['kodekuncip'];
	 	$namakunci = $i['namakunci'];
	 	$namapeminjam = $i['namapeminjam'];
	 	$statuspinjam = $i['statuspinjam'];
	 	$waktupinjam = $i['waktupinjam'];
	 	$waktukembali = $i['waktukembali'];
    ?>
    <div class="modal fade" id="modal_pengembalian<?php echo $idkuncip;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #bd7400;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Form Pengembalian Kunci</h2>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url().'KA/kembali_kunci/'.$idkuncip;?>">
                    <div class="modal-body">
                        <div class="form-group row">
                        	<input name="idkuncip" value="<?php echo $idkuncip;?>" class="form-control" type="hidden" placeholder="ID pendaftaran..." readonly>
                        	<label class="control-label col-4" >Kode Kunci</label>
                            <div class="col-8">
                                <input id="inputenable" name="kodekuncip" value="<?php echo $kodekuncip;?>" class="form-control" type="text" readonly>
                            </div>

                            <label class="control-label col-4" >Nama Kunci</label>
                            <div class="col-8">
                                <input id="inputenable" name="namakunci" value="<?php echo $namakunci;?>" class="form-control" type="text" readonly>
                            </div>
                        
                            <label class="control-label col-4" >Nama Peminjam</label>
                            <div class="col-8">
                                <input id="inputenable" name="namapeminjam" value="<?php echo $namapeminjam;?>" class="form-control" readonly>
                            </div>   

                            <label class="control-label col-4" >Waktu Peminjaman</label>
                            <div class="col-8">
                                <input id="inputenable" name="waktupinjam" value="<?php echo $waktupinjam;?>" class="form-control" readonly>
                            </div>

                            <label class="control-label col-4" >Waktu Pengembalian</label>
                            <div class="col-8">
                                <input id="inputenable" type="datetime-local" name="waktukembali" class="form-control" required>
                            </div>              

                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-info" type="submit">OK</button>
                            <button class="btn btn-secondary" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        </div>
                </div>
           </form>
        </div>
    </div>
</div>

<?php endforeach;?>
<!-- end modal pengembalian kunci -->

    <!-- modal edit kunci -->
    <?php 
        foreach($kunci->result_array() as $i):
        $idkuncip=$i['idkuncip'];
        $kodekuncip = $i['kodekuncip'];
        $namakunci = $i['namakunci'];
        $namapeminjam = $i['namapeminjam'];
        $statuspinjam = $i['statuspinjam'];
        $waktupinjam = $i['waktupinjam'];
        $waktukembali = $i['waktukembali'];
    ?>
    <div class="modal fade" id="modal_edit<?php echo $idkuncip;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #bd7400;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Ganti Nama Kunci</h2>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url().'KA/edit_kunci/'.$idkuncip;?>">
                    <div class="modal-body">
                        <div class="form-group row">
                            <input name="idkuncip" value="<?php echo $idkuncip;?>" class="form-control" type="hidden" placeholder="ID pendaftaran..." readonly>
                            <label class="control-label col-4" >Kode Kunci</label>
                            <div class="col-8">
                                <input id="inputenable" name="" value="<?php echo $kodekuncip;?>" class="form-control" type="text" readonly>
                            </div>

                            <label class="control-label col-4" >Nama Kunci</label>
                            <div class="col-8">
                                <input id="inputenable" name="namakunci" value="<?php echo $namakunci;?>" class="form-control" type="text" autofocus>
                            </div>                    
                        
                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-info" type="submit">Ganti</button>
                            <button class="btn btn-secondary" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        </div>
                </div>
           </form>
        </div>
    </div>
</div>

<?php endforeach;?>
<!-- end modal edit kunci -->


	<!-- modal delete kunci -->
 	<?php 
        foreach($kunci->result_array() as $i):
        $idkuncip=$i['idkuncip'];
	 	$kodekuncip = $i['kodekuncip'];
	 	$namakunci = $i['namakunci'];
	 	$namapeminjam = $i['namapeminjam'];
	 	$statuspinjam = $i['statuspinjam'];
	 	$waktupinjam = $i['waktupinjam'];
	 	$waktukembali = $i['waktukembali'];
    ?>
        <div class="modal fade" id="modal_delete<?php echo $idkuncip;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #820707;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Konfirmasi Hapus Akun</h2>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url().'KA/hapus_kunci'?>">
                    <div class="modal-body">
                        <div class="form-group row">
                        	<input name="idkuncip" value="<?php echo $idkuncip;?>" class="form-control" type="hidden" placeholder="ID pendaftaran..." readonly>
                            <label class="control-label col-4" >Kode Kunci</label>
                            <div class="col-8">
                                <input id="inputdisable" name="kodekuncip" value="<?php echo $kodekuncip;?>" class="form-control" type="text" readonly>
                            </div>

                            <label class="control-label col-4" >Nama Kunci</label>
                            <div class="col-8">
                                <input id="inputdisable" name="namakunci" value="<?php echo $namakunci;?>" class="form-control" type="text" readonly>
                            </div>
                        
                            <label class="control-label col-4" >Status Kunci</label>
                            <div class="col-8">
                                <input id="inputdisable" name="statuspinjam" value="<?php echo $statuspinjam;?>" class="form-control" type="text" readonly>
                            </div>                        
                     
                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-danger" type="submit">Hapus</button>
                            <button class="btn btn-secondary" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach;?>
    <!-- end modal delete kunci -->


	<br><br><br> 	
	<footer style="color: white;">
	    <center><p>Copyright &copy; 2020 | <b>LNProduction</b>. All rights reserved.</p></center>  
	</footer>
</body>
</div>