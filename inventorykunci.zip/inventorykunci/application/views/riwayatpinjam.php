<div class="container">
	<center><h4 class="display-4">Riwayat Peminjaman Kunci</h4><hr></center>
	  <table class="tabledark display compact" id="mydata" style="width: 99.9%;">
	  	<thead>
	  		<tr>
	  			<th><center>No</center></th>
	  			<th><center>Kode Kunci</center></th>
  			 	<th><center>Nama Kunci</center></th>
  			 	<th><center>Nama Peminjam</center></th>
  			 	<th><center>Status Kunci</center></th>
  			 	<th><center>Waktu Peminjam</center></th>
  			 	<th><center>Waktu Pengembalian</center></th>
	  		</tr>
	  	</thead>
	  	<tbody>
	  		<?php  
        		$no = 0;
        		 foreach($kunci->result_array()as$terdaftar):
        		 	$no++;
        		 	$idriwayat=$terdaftar['idriwayat'];
        		 	$kodekuncipr = $terdaftar['kodekuncipr'];
        		 	$namakuncipr = $terdaftar['namakuncipr'];
        		 	$namapeminjamr = $terdaftar['namapeminjamr'];
        		 	$satuspinjamr = $terdaftar['satuspinjamr'];
        		 	$waktupinjamr = $terdaftar['waktupinjamr'];
        		 	$waktukembalir = $terdaftar['waktukembalir'];
        	?>
        	<tr>
        		<td align="center"><?php echo $no; ?></td>
                <td align="center"><?php echo $kodekuncipr; ?></td>
                <td align="center"><?php echo $namakuncipr; ?></td>
                <td align="center"><?php echo $namapeminjamr; ?></td>             
                <td align="center" style="background-color: #006622;"><?php echo $satuspinjamr; ?></td>
                <td align="center"><?php echo $waktupinjamr; ?></td>
                <td align="center"><?php echo $waktukembalir; ?></td>
        	</tr>	
        	 <?php endforeach;?>
	  	</tbody>
	  </table>
	  
	  <br><br><br> 	
	<footer style="color: white;">
	    <center><p>Copyright &copy; 2020 | <b>LNProduction</b>. All rights reserved.</p></center>  
	</footer>
</div>