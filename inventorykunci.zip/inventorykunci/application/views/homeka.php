<div class="container" >
	<center><h4 class="display-4">Informasi Kunci</h4><hr></center>
        <div id="load_content">
            <table class="tabledark display compact" id="mydata" style="width: 99.9%;">
            <thead>
                <tr>
                    <th><center>No</center></th>
                    <th><center>Kode Kunci</center></th>
                    <th><center>Nama Kunci</center></th>
                    <th><center>Nama Peminjam</center></th>
                    <th><center>Status Kunci</center></th>
                </tr>
            </thead>
            <tbody>
                <?php  
                    $no = 0;
                     foreach($kunci->result_array()as$terdaftar):
                        $no++;
                        $idkuncip=$terdaftar['idkuncip'];
                        $kodekuncip = $terdaftar['kodekuncip'];
                        $namakunci = $terdaftar['namakunci'];
                        $namapeminjam = $terdaftar['namapeminjam'];
                        $statuspinjam = $terdaftar['statuspinjam'];
                        $waktupinjam = $terdaftar['waktupinjam'];
                        $waktukembali = $terdaftar['waktukembali'];
                ?>
                <tr>
                    <td align="center"><?php echo $no; ?></td>
                    <td align="center"><?php echo $kodekuncip; ?></td>
                    <td align="center"><?php echo $namakunci; ?></td>
                    <td align="center"><?php echo $namapeminjam; ?></td>
                    <?php  
                    if ($statuspinjam == "tersedia")
                    {
                        $ket = "Tersedia";
                    ?>
                         <td align="center" style="background-color: #006622;"><?php echo $ket; ?></td>
                    <?php
                    }
                    elseif ($statuspinjam == "dipinjam")
                    {
                        $ket = "Dipinjam";
                    ?>
                        <td align="center" style="background-color: #990000;"><?php echo $ket; ?></td>
                    <?php
                    }
                    ?>
                </tr>
                 <?php endforeach;?>
            </tbody>
          </table>
        </div>

	<br><br><br> 	
	<footer style="color: white;">
	    <center><p>Copyright &copy; 2020 | <b>LNProduction</b>. All rights reserved.</p></center>  
	</footer>
</div>