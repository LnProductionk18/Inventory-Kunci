<div class="container">
	<center><h4 class="display-4">Data User</h4><hr></center>
	 <button id="tambahdata" class="btn btn-lg btn-outline-success" data-toggle="modal" data-target="#modal_tambah">Tambah User</button><br><br>
    <br><br>
	 <table class="tabledark display compact" id="mydata" style="width: 99.9%;">
	 	 <thead>
            <tr>
                <th><center>No</center></th>
                <th><center>Nama</center></th>
                <th><center>Username</center></th>
                <th><center>Password</center></th>
                <th><center>Hak Akses</center></th>
                <!-- <th><center>Keterangan</center></th> -->
                <th><center>Edit</center></th>
            </tr>
        </thead>
        <tbody>
        	<?php  
        		$no = 0;
        		 foreach($akun->result_array()as$terdaftar):
        		 	$no++;
        		 	$idakses=$terdaftar['idakses'];
        		 	$nama = $terdaftar['nama'];
        		 	$username = $terdaftar['username'];
        		 	$password = $terdaftar['password'];
        		 	$level = $terdaftar['level'];
        		 	if ($level == "1") 
					{
						$ket="Ketua Admin";
					}
					else
					{
						$ket="Admin";
					}
        	?>
        	<tr>
        		<td align="center"><?php echo $no; ?></td>
                <td align="center"><?php echo $nama; ?></td>
                <td align="center"><?php echo $username; ?></td>
                <td align="center"><?php echo $password; ?></td>
                <!-- <td align="center"><?php echo $level; ?></td> -->
                <td align="center"><?php echo $ket; ?></td>
                <td align="center">
                    <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#modal_edit<?php echo $idakses;?>">Edit</button>
                   <!--  <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal_delete<?php echo $idakses;?>">Hapus</button> -->
                </td>
        	</tr>
        	 <?php endforeach;?>
        </tbody>
	 </table>

	   <!-- Modal tambah akun  -->
    <div class="modal fade" id="modal_tambah" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #26b7ba;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Form Daftar User</h2>
                </div>
                <?php echo form_open("KA/simpan_akun", array('enctype'=>'multipart/form-data')); ?>
                    <div class="modal-body">
                        <div class="form-group row">
                            <label class="control-lable col-4">Nama</label>
                            <div class="col-8">
                                <input id="inputenable" type="text" name="nama" class="form-control" type="text" required autofocus>
                            </div>
                        
                            <label class="control-lable col-4">Username</label>
                            <div class="col-8">
                                <input id="inputenable" type="text" name="username" class="form-control" type="text" required>
                            </div>
                        
                            <label class="control-lable col-4">Password</label>
                            <div class="col-8">
                                <input id="inputenable" name="password" class="form-control form-password" type="password" required>
                                <div class="custom-control custom-checkbox mb-3">
                                    <input type="checkbox" class="custom-control-input form-checkbox" id="customCheck" name="example1">
                                    <label style="font-size: 14px;" class="custom-control-label" for="customCheck">Show Password</label>
                                </div>
                            </div>
                        
                            <label class="control-lable col-4">Hak Akses</label>
                            <div class="col-8">
                                <select id="inputenable" class="form-control" name="level" required>
                                    <option value="">Hak Akses</option>
                                    <option value="1">1 | Ketua Admin</option>
                                    <option value="2">2 | Admin</option>
                                </select>
                            </div>
                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-success" type="submit">Tambah</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
             	<?php echo form_close(); ?>
          </div>
      </div>
  	</div >
  <!-- end modal tambah akun -->

    <!-- modal edit akun -->
	<?php 
        foreach($akun->result_array() as $i):
        $idakses=$i['idakses'];
        $nama=$i['nama'];
        $username=$i['username'];
        $password=$i['password'];
        $level=$i['level'];
    ?>
    <div class="modal fade" id="modal_edit<?php echo $idakses;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #bd7400;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Ubah Akun</h2>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url().'KA/edit_akun/'.$idakses;?>">
                    <div class="modal-body">
                        <div class="form-group row">
                        	 <input name="idakses" value="<?php echo $idakses;?>" class="form-control" type="hidden" placeholder="ID pendaftaran..." readonly>
                            <label class="control-label col-4" >Name</label>
                            <div class="col-8">
                                <input id="inputenable" name="nama" value="<?php echo $nama;?>" class="form-control" type="text" required>
                            </div>
                        
                            <label class="control-label col-4" >Username </label>
                            <div class="col-8">
                                <input id="inputenable" name="username" value="<?php echo $username;?>" class="form-control" required>
                            </div>

                            <label class="control-label col-4" >Password </label>
                            <div class="col-8">
                                <input id="inputenable" name="password" class="form-control form-password" type="password" required>
                                <div class="custom-control custom-checkbox mb-3">
                                    <input type="checkbox" class="custom-control-input form-checkbox" id="customCheck<?php echo $username;?>" name="example1<?php echo $username;?>">
                                    <label style="font-size: 14px;" class="custom-control-label" for="customCheck<?php echo $username;?>">Show Password</label>
                                </div>
                            </div>

                          <!--   <label class="control-label col-4" >Level</label>
                            <div class="col-8">
                             <select id="inputenable" class="form-control" name="level" required>
                                <option value="">Hak Akses</option>
                               	<option value="1">1 | Ketua Admin</option>
                                <option value="2">2 | Admin</option>
                            </select>
                            </div> -->
                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-info" type="submit">Update</button>
                            <button class="btn btn-secondary" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php endforeach;?>
<!-- end modal edit akun -->


<!-- modal delete akun -->
<!-- <?php 
foreach($akun->result_array() as $i):
	$idakses=$i['idakses'];
    $nama=$i['nama'];
    $username=$i['username'];
    $password=$i['password'];
    $level=$i['level'];
    ?>
    <div class="modal fade" id="modal_delete<?php echo $idakses;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #242424;">
                <div class="alert" style="background-color: #820707;" align="center"><span style="position: absolute; left: 96%;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    </span><h2 style="color: white;">Konfirmasi Hapus Akun</h2>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url().'KA/hapus_akun'?>">
                    <div class="modal-body">
                        <div class="form-group row">
                        	<input name="idakses" value="<?php echo $idakses;?>" class="form-control" type="hidden" placeholder="ID pendaftaran..." readonly>
                            <label class="control-label col-4" >Name</label>
                            <div class="col-8">
                                <input id="inputdisable" name="nama" value="<?php echo $nama;?>" class="form-control" type="text" readonly>
                            </div>

                            <label class="control-label col-4" >Username </label>
                            <div class="col-8">
                                <input id="inputdisable" name="username" value="<?php echo $username;?>" class="form-control" type="text" readonly>
                            </div>
                        
                            <label class="control-label col-4" >Password </label>
                            <div class="col-8">
                                <input id="inputdisable" name="password" value="<?php echo $password;?>" class="form-control" type="text" readonly>
                            </div>
                        
                            <label class="control-label col-4" >Level</label>
                            <div class="col-8">
                                <input id="inputdisable" name="level" value="<?php echo $level.' | '.'&nbsp;'; echo $ket;?>" class="form-control" type="text" readonly>
                            </div>
                        </div>
                        <hr style="background-color: #454545;">
                        <div align="right">
                            <button class="btn btn-danger" type="submit">Hapus</button>
                            <button class="btn btn-secondary" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php endforeach;?> -->
<!-- end modal delete akun -->
    
    <br><br><br>
    <footer style="color: white;">
        <center><p>Copyright &copy; 2020 | <b>LNProduction</b>. All rights reserved.</p></center>  
    </footer>
</body>
</div>

</body>